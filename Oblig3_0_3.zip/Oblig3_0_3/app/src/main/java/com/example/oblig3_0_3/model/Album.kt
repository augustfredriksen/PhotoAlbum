package com.example.oblig3_0_3.model

data class Album(
    val userId : Int,
    val id : Int,
    val title: String
)
