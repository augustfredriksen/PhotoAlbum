package com.example.oblig3_0_3.model

data class Photo(
    val albumId : Int,
    val id : Int,
    var title : String,
    val url : String,
    val thumbnailUrl : String
)
