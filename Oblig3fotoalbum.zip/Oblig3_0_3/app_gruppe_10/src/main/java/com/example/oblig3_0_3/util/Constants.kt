package com.example.oblig3_0_3.util

class Constants {

    companion object {

        const val BASE_URL = "https://jsonplaceholder.typicode.com"

    }
}