package com.example.oblig3_0_3.adapter

import androidx.recyclerview.widget.LinearLayoutManager
import com.example.oblig3_0_3.screens.users.UserFragment

interface MyOnClickListener {
    fun onClick(position: Int)
}