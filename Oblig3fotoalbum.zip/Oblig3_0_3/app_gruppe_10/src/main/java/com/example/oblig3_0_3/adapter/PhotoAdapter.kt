package com.example.oblig3_0_3.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.oblig3_0_3.databinding.FragmentPhotoBinding
import com.example.oblig3_0_3.databinding.RowLayoutUserBinding
import com.example.oblig3_0_3.model.Album
import com.example.oblig3_0_3.model.Photo

class PhotoAdapter {

}
