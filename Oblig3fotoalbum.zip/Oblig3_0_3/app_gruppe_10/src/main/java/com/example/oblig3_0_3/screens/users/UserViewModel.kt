package com.example.oblig3_0_3.screens.users

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.oblig3_0_3.model.User
import com.example.oblig3_0_3.repository.Repository
import kotlinx.coroutines.launch
import retrofit2.Response

class UserViewModel(private val repository: Repository): ViewModel() {

    var myUsers: MutableLiveData<Response<List<User>>> = MutableLiveData()

    fun getUsers() {
        viewModelScope.launch {
            val response: Response<List<User>> = repository.getUsers()
            myUsers.value = response
        }
    }

}